NDK=/home/abc/android-ndk-r26c
cd jni
$NDK/ndk-build
cd ..

