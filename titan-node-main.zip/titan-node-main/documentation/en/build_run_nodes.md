## 1 Run Candidate or Edge
    titan-candidate daemon start --init --url https://your-titan-network/rpc/v0
    titan-edge daemon start --init --url https://your-titan-network/rpc/v0

