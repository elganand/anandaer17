package main

func killApp(appName string) error {
	return nil
}
