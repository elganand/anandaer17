package asset

import (
	"testing"
)

func TestImpl(t *testing.T) {
	t.Log("TestImpl")
}
